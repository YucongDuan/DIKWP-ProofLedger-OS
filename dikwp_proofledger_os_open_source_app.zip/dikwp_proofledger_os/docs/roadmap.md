# Roadmap

## v0.1
Local lexical claim-evidence proof ledger.

## v0.2
Multilingual claim extraction and citation scope analyzer.

## v0.3
Semantic entailment adapter and contradiction classifier.

## v0.4
Human review workflow and team dashboard.

## v0.5
MCP / LangChain / LlamaIndex adapters.

## v1.0
Enterprise-ready evidence governance layer with audit export.
