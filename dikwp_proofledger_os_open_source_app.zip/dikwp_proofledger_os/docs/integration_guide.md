# Integration Guide

## RAG pipeline

Use ProofLedger after answer generation and before user display:

1. RAG retrieves documents.
2. Model generates answer with citation markers.
3. ProofLedger checks claim-to-source alignment.
4. Low-support claims are demoted, reviewed, or removed.
5. Final output includes Reliability Gradient and residuals.

## Agent pipeline

Use ProofLedger before external actions:

1. Agent drafts report or proposed decision.
2. IntentGuard checks prompt/tool safety.
3. ProofLedger checks evidence support.
4. MemoryLedger stores only governed validated context.
5. SemanticEnergy audits cost-value efficiency.

## Enterprise report workflow

Use ProofLedger to create an evidence appendix from drafts.
