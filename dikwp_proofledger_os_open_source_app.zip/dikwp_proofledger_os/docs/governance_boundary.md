# Governance Boundary

Do not use ProofLedger OS to fabricate support, launder weak evidence, or present citation presence as truth.

The tool is a local verifier. It does not independently prove that a source is true, current, legally sufficient, or complete.

High-stakes domains require primary sources and human review.
