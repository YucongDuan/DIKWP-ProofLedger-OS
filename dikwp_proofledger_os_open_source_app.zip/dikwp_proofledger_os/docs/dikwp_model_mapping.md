# DIKWP Model Mapping

| Layer | Product interpretation |
|---|---|
| Data | Answer text, source snippets, citations, timestamps, source IDs |
| Information | Claim-source relations, citation links, overlap, missing evidence, conflict flags |
| Knowledge | Claim types, support rules, proof states, evidence coverage, reliability classes |
| Wisdom | Risk weighting, high-stakes boundaries, humility over false certainty |
| Purpose | Local verification objective: make output auditable and correctable |
| Reliability | Supported / Provisional / Borrowed / Hollow / Contested / Blocked |
