# Documentation Index

- `product_brief_zh.md`
- `architecture.md`
- `market_research_summary.md`
- `dikwp_model_mapping.md`
- `integration_guide.md`
- `governance_boundary.md`
- `open_source_launch_plan.md`
- `roadmap.md`
- `landing_page_copy.md`
- `github_release_draft.md`
- `source_synthesis.md`
