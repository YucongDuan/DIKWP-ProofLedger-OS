# DIKWP ProofLedger OS 产品简报

**DIKWP ProofLedger OS** 是一款开源 AI 证据账本与引文完整性审计工具。

它解决的问题不是“让 AI 更会说”，而是“让 AI 输出可被审计、可降权、可纠错、可回滚”。

核心能力：

- 把 AI/RAG 输出拆成原子 Claim Cards。
- 检查每条 claim 是否有 citation。
- 检查 citation 是否真实对应该 claim。
- 生成 Evidence Ledger、Reliability Label、Kill/Recovery。
- 输出 allow / review / block。
- 给企业、研究、内容、政策、品牌团队提供白盒 AI 输出治理入口。

市场定位：AI hallucination triage、RAG citation integrity、AI policy evidence ledger、enterprise answer governance。

该项目为 DIKWP 生态提供一个非常容易被企业采用的开源入口：所有 AI 应用最终都需要“证据层”。
