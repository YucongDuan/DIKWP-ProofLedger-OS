# Architecture

DIKWP ProofLedger OS follows a local-first pipeline:

1. Input AI answer and source bundle.
2. Extract sentence-level candidate claims.
3. Extract citation markers.
4. Align claims to all source snippets using transparent lexical matching.
5. Score citation validity and source support.
6. Register each claim as C=(D,I,K,W,P,R).
7. Assign Reliability Gradient and decision.
8. Export JSON, CSV and Markdown governance reports.

The first version deliberately avoids hidden web browsing or proprietary entailment models. This makes the system auditable and easy to extend.

Future adapters can add semantic entailment, multilingual extraction, vector search, source freshness checks, and human review workflow.
