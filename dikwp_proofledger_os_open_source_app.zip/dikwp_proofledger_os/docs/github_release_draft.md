# Release v0.1.0

DIKWP ProofLedger OS is now available.

This release includes:

- Claim extraction
- Citation marker extraction
- Claim-source alignment
- DIKWP claim cards
- Reliability labels
- JSON/CSV/Markdown reports
- CLI
- Optional Streamlit dashboard
- Static boundary audit

This is a local-first scaffold. It is not a truth oracle.
