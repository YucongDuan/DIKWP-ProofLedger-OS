# Code of Conduct

Be precise, evidence-oriented, and respectful. Disagreement is welcome when it improves reliability.
