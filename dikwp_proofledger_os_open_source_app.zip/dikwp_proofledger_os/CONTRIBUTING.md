# Contributing

Contributions are welcome. Please keep the project white-box, local-first, evidence-first, and non-deceptive.

Do not add hidden network calls, credential collection, scraping bypasses, or source fabrication features.
