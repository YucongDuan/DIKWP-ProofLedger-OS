from __future__ import annotations

from typing import Dict, List, Any


def register_claim_dikwp(claim_text: str, source_ids: List[str], support_score: float, purpose: str, risk_flags: List[str]) -> Dict[str, Any]:
    return {
        "D": {
            "raw_claim": claim_text,
            "linked_sources": source_ids,
            "observable_artifacts": ["claim text", "citation markers", "source snippets"]
        },
        "I": {
            "relations": ["claim-to-source", "citation-to-source", "claim-to-purpose"],
            "support_score": round(support_score, 4),
            "risk_flags": risk_flags
        },
        "K": {
            "mechanism": "local lexical claim-evidence alignment plus citation validity checks",
            "limits": "not a truth oracle; semantic entailment requires stronger models or human review"
        },
        "W": {
            "value_boundary": "prefer evidence humility over persuasive unsupported certainty",
            "risk_weighting": "high-strength claims without evidence are demoted first"
        },
        "P": {
            "local_purpose": purpose,
            "proof_intent": "make the answer auditable, demotable, correctable, and reversible"
        },
        "R": {
            "reliability_basis": "borrowed from provided sources plus local matching algorithm",
            "residual": "source truth and completeness are not independently verified by this local tool"
        }
    }
