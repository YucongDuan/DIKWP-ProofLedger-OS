"""DIKWP ProofLedger OS."""

__version__ = "0.1.0"
