from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

from .dikwp import register_claim_dikwp
from .models import Source, Claim, EvidenceMatch, ClaimCard, ProofLedgerReport
from .text_utils import (
    compact_snippet,
    extract_citations,
    classify_claim,
    jaccard,
    split_sentences,
    strength_flags,
    tokenize,
)


class ProofLedgerAnalyzer:
    def __init__(self, support_threshold: float = 0.18, citation_threshold: float = 0.40) -> None:
        self.support_threshold = support_threshold
        self.citation_threshold = citation_threshold

    def load_sources(self, source_json_path: str | Path) -> List[Source]:
        path = Path(source_json_path)
        data = json.loads(path.read_text(encoding="utf-8"))
        sources = []
        for item in data.get("sources", data if isinstance(data, list) else []):
            sources.append(Source(**item))
        return sources

    def extract_claims(self, answer_text: str) -> List[Claim]:
        claims: List[Claim] = []
        for idx, sent in enumerate(split_sentences(answer_text), start=1):
            if len(sent) < 12:
                continue
            citations = extract_citations(sent)
            claims.append(
                Claim(
                    claim_id=f"C{idx:03d}",
                    text=sent,
                    citations=citations,
                    claim_type=classify_claim(sent),
                    strength_flags=strength_flags(sent),
                )
            )
        return claims

    def align_claim_to_sources(self, claim: Claim, sources: List[Source]) -> List[EvidenceMatch]:
        claim_tokens = tokenize(claim.text)
        matches: List[EvidenceMatch] = []
        for src in sources:
            src_tokens = tokenize(src.text)
            score = jaccard(claim_tokens, src_tokens)
            matched = sorted(set(claim_tokens) & set(src_tokens))[:24]
            matches.append(
                EvidenceMatch(
                    source_id=src.source_id,
                    score=score,
                    matched_terms=matched,
                    snippet=compact_snippet(src.text, matched),
                )
            )
        matches.sort(key=lambda m: m.score, reverse=True)
        return matches[:5]

    def citation_validity(self, claim: Claim, sources_by_id: Dict[str, Source], matches: List[EvidenceMatch]) -> Tuple[float, List[str]]:
        flags: List[str] = []
        if not claim.citations:
            flags.append("missing_citation")
            return 0.0, flags
        valid_ids = [c for c in claim.citations if c in sources_by_id]
        if len(valid_ids) < len(claim.citations):
            flags.append("citation_id_not_found")
        if not valid_ids:
            return 0.0, flags
        match_scores = {m.source_id: m.score for m in matches}
        cited_scores = [match_scores.get(cid, 0.0) for cid in valid_ids]
        mean = sum(cited_scores) / len(cited_scores)
        if mean < self.citation_threshold:
            flags.append("citation_low_alignment")
        return min(1.0, mean / max(self.support_threshold, 1e-9)), flags

    def make_claim_card(self, claim: Claim, sources: List[Source], purpose: str) -> ClaimCard:
        sources_by_id = {s.source_id: s for s in sources}
        matches = self.align_claim_to_sources(claim, sources)
        best_score = matches[0].score if matches else 0.0
        citation_score, citation_flags = self.citation_validity(claim, sources_by_id, matches)
        risk_flags = list(claim.strength_flags) + citation_flags

        if "strong_unqualified_language" in risk_flags and best_score < self.support_threshold * 1.25:
            risk_flags.append("overconfident_unsupported_claim")
        if claim.claim_type == "action_or_recommendation" and best_score < self.support_threshold:
            risk_flags.append("action_without_sufficient_evidence")
        if claim.claim_type == "quantitative" and not claim.citations:
            risk_flags.append("numeric_claim_without_citation")
        # Simple contradiction heuristic: a claim that uses guarantee/always language
        # conflicts with best evidence that explicitly negates such guarantee.
        best_snippet = matches[0].snippet.lower() if matches else ""
        lowered_claim = claim.text.lower()
        if any(x in lowered_claim for x in ["guarantee", "guarantees", "guaranteed", "保证", "绝对"]):
            if any(x in best_snippet for x in ["does not guarantee", "cannot guarantee", "not guarantee", "不保证", "不能保证"]):
                risk_flags.append("source_contradiction_signal")

        reliability = self.reliability_label(best_score, citation_score, risk_flags)
        decision = self.decision_from_reliability(reliability, risk_flags)
        dikwp = register_claim_dikwp(
            claim.text,
            [m.source_id for m in matches if m.score >= self.support_threshold],
            best_score,
            purpose,
            risk_flags,
        )
        kill_conditions = [
            "cited source cannot be recovered",
            "source contradicts the claim on manual review",
            "claim is quantitative but no primary measurement source is supplied",
            "source is outdated or outside the claim scope",
        ]
        recovery_actions = [
            "downgrade the claim to Provisional or Hollow",
            "attach a stronger source or narrower wording",
            "split compound claim into atomic claims",
            "add human expert review for high-stakes claims",
        ]
        return ClaimCard(
            claim_id=claim.claim_id,
            claim_text=claim.text,
            citations=claim.citations,
            claim_type=claim.claim_type,
            support_score=round(best_score, 4),
            citation_validity_score=round(citation_score, 4),
            evidence_matches=matches,
            risk_flags=risk_flags,
            dikwp=dikwp,
            reliability=reliability,
            decision=decision,
            kill_conditions=kill_conditions,
            recovery_actions=recovery_actions,
        )

    def reliability_label(self, support_score: float, citation_score: float, risk_flags: List[str]) -> str:
        if "citation_id_not_found" in risk_flags or "source_contradiction_signal" in risk_flags:
            return "Blocked"
        if support_score >= 0.35 and citation_score >= 0.75 and "overconfident_unsupported_claim" not in risk_flags:
            return "Supported"
        if support_score >= self.support_threshold and citation_score >= 0.2:
            return "Provisional"
        if support_score >= self.support_threshold and not citation_score:
            return "Borrowed"
        if support_score > 0.05:
            return "Hollow"
        return "Blocked"

    @staticmethod
    def decision_from_reliability(reliability: str, risk_flags: List[str]) -> str:
        if reliability in {"Supported"} and not any(f in risk_flags for f in ["action_without_sufficient_evidence", "overconfident_unsupported_claim"]):
            return "allow"
        if reliability in {"Provisional", "Borrowed", "Hollow"}:
            return "review"
        return "block"

    def verify(self, answer_text: str, sources: List[Source], purpose: str = "Verify AI/RAG output") -> ProofLedgerReport:
        claims = self.extract_claims(answer_text)
        cards = [self.make_claim_card(c, sources, purpose) for c in claims]
        decision_summary = {"allow": 0, "review": 0, "block": 0}
        for card in cards:
            decision_summary[card.decision] = decision_summary.get(card.decision, 0) + 1
        supported_count = decision_summary.get("allow", 0)
        review_count = decision_summary.get("review", 0)
        blocked_count = decision_summary.get("block", 0)
        mean_support = sum(c.support_score for c in cards) / len(cards) if cards else 0.0
        mean_citation = sum(c.citation_validity_score for c in cards) / len(cards) if cards else 0.0
        unsupported_rate = blocked_count / len(cards) if cards else 0.0
        citation_abuse = sum(1 for c in cards if any(f in c.risk_flags for f in ["citation_low_alignment", "citation_id_not_found"])) / len(cards) if cards else 0.0
        evidence_coverage = sum(1 for c in cards if c.support_score >= self.support_threshold) / len(cards) if cards else 0.0
        proof_score = max(0.0, min(1.0, 0.45 * mean_support / 0.35 + 0.25 * mean_citation + 0.20 * evidence_coverage + 0.10 * (1 - citation_abuse) - 0.25 * unsupported_rate))
        residual = [
            "Local lexical evidence matching cannot prove full semantic entailment.",
            "The tool does not independently verify whether supplied sources are true or current.",
            "Contradiction detection is heuristic and should be escalated for high-stakes outputs.",
            "Regulatory, medical, legal, financial and safety claims require expert review."
        ]
        action_boundary = [
            "Do not use the score as a legal certification.",
            "Do not fabricate sources or citations to improve scores.",
            "Do not treat citation presence as proof of source support.",
            "For high-stakes claims, require primary sources and human review."
        ]
        return ProofLedgerReport(
            system="DIKWP ProofLedger OS",
            version="0.1.0",
            purpose=purpose,
            answer_length_chars=len(answer_text),
            source_count=len(sources),
            claim_count=len(cards),
            supported_count=supported_count,
            review_count=review_count,
            blocked_count=blocked_count,
            mean_support_score=round(mean_support, 4),
            mean_citation_validity_score=round(mean_citation, 4),
            evidence_coverage_score=round(evidence_coverage, 4),
            unsupported_claim_rate=round(unsupported_rate, 4),
            citation_abuse_rate=round(citation_abuse, 4),
            proofledger_score=round(proof_score, 4),
            decision_summary=decision_summary,
            action_boundary=action_boundary,
            residual=residual,
            claim_cards=cards,
        )
