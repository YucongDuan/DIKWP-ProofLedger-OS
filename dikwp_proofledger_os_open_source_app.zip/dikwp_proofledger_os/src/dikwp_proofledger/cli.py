from __future__ import annotations

import argparse
from pathlib import Path

from .analyzer import ProofLedgerAnalyzer
from .reports import write_all_outputs
from .static_audit import write_audit


def cmd_verify(args: argparse.Namespace) -> int:
    answer_text = Path(args.answer).read_text(encoding="utf-8")
    analyzer = ProofLedgerAnalyzer(support_threshold=args.support_threshold, citation_threshold=args.citation_threshold)
    sources = analyzer.load_sources(args.sources)
    report = analyzer.verify(answer_text, sources, purpose=args.purpose)
    write_all_outputs(args.out, report, sources)
    print(f"ProofLedger score: {report.proofledger_score}; claims={report.claim_count}; decisions={report.decision_summary}")
    return 0


def cmd_static_audit(args: argparse.Namespace) -> int:
    report = write_audit(args.path, args.out)
    print(f"Static audit pass={report['pass']} findings={report['finding_count']}")
    return 0 if report["pass"] else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dikwp-proofledger")
    sub = parser.add_subparsers(dest="command", required=True)
    verify = sub.add_parser("verify", help="Verify an AI/RAG answer against supplied sources")
    verify.add_argument("answer")
    verify.add_argument("sources")
    verify.add_argument("--out", default="outputs/demo")
    verify.add_argument("--purpose", default="Verify AI/RAG output")
    verify.add_argument("--support-threshold", type=float, default=0.18)
    verify.add_argument("--citation-threshold", type=float, default=0.40)
    verify.set_defaults(func=cmd_verify)

    audit = sub.add_parser("static-audit", help="Run static boundary audit")
    audit.add_argument("path")
    audit.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    audit.set_defaults(func=cmd_static_audit)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
