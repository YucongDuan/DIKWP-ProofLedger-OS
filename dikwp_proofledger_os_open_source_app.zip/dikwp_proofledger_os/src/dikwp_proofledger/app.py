from __future__ import annotations

import json

from .analyzer import ProofLedgerAnalyzer
from .models import Source


def main():
    import streamlit as st
    st.set_page_config(page_title="DIKWP ProofLedger OS", layout="wide")
    st.title("DIKWP ProofLedger OS")
    st.caption("Local claim-evidence verification for AI/RAG outputs")
    answer = st.text_area("AI answer", height=240)
    sources_json = st.text_area("Sources JSON", height=240, value='{"sources": []}')
    if st.button("Verify"):
        try:
            data = json.loads(sources_json)
            sources = [Source(**x) for x in data.get("sources", [])]
            report = ProofLedgerAnalyzer().verify(answer, sources)
            st.metric("ProofLedger score", report.proofledger_score)
            st.json(report.to_dict())
        except Exception as exc:
            st.error(str(exc))


if __name__ == "__main__":
    main()
