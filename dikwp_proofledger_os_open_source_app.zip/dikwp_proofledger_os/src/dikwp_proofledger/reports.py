from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import List

from .models import ProofLedgerReport, Source


def write_json(path: str | Path, data) -> None:
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_claim_cards_csv(path: str | Path, report: ProofLedgerReport) -> None:
    with Path(path).open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["claim_id", "decision", "reliability", "support_score", "citation_validity_score", "claim_type", "citations", "risk_flags", "claim_text"])
        for card in report.claim_cards:
            writer.writerow([
                card.claim_id,
                card.decision,
                card.reliability,
                card.support_score,
                card.citation_validity_score,
                card.claim_type,
                ";".join(card.citations),
                ";".join(card.risk_flags),
                card.claim_text,
            ])


def write_alignment_csv(path: str | Path, report: ProofLedgerReport) -> None:
    with Path(path).open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["claim_id", "source_id", "score", "matched_terms", "snippet"])
        for card in report.claim_cards:
            for match in card.evidence_matches:
                writer.writerow([card.claim_id, match.source_id, match.score, " ".join(match.matched_terms), match.snippet])


def write_source_coverage(path: str | Path, report: ProofLedgerReport, sources: List[Source]) -> None:
    coverage = {s.source_id: {"title": s.title, "matched_claims": 0, "max_score": 0.0} for s in sources}
    for card in report.claim_cards:
        for match in card.evidence_matches:
            item = coverage.get(match.source_id)
            if not item:
                continue
            if match.score >= 0.18:
                item["matched_claims"] += 1
            item["max_score"] = max(item["max_score"], match.score)
    write_json(path, coverage)


def write_recommendations(path: str | Path, report: ProofLedgerReport) -> None:
    lines = [
        "# DIKWP ProofLedger Recommendations",
        "",
        f"ProofLedger score: **{report.proofledger_score}**",
        f"Claims: {report.claim_count}; allow={report.supported_count}, review={report.review_count}, block={report.blocked_count}",
        "",
        "## Highest priority fixes",
    ]
    blocked = [c for c in report.claim_cards if c.decision == "block"]
    review = [c for c in report.claim_cards if c.decision == "review"]
    if not blocked and not review:
        lines.append("- No critical issues found in this local audit.")
    for card in blocked[:8]:
        lines.append(f"- **Block {card.claim_id}**: {card.claim_text}")
        lines.append(f"  - Risk flags: {', '.join(card.risk_flags) or 'none'}")
        lines.append("  - Recovery: add primary source, narrow claim, or remove unsupported assertion.")
    for card in review[:8]:
        lines.append(f"- **Review {card.claim_id}**: {card.claim_text}")
        lines.append(f"  - Reliability: {card.reliability}; support={card.support_score}; citation={card.citation_validity_score}")
    lines += [
        "",
        "## Governance boundary",
        "- Citation presence is not proof of citation support.",
        "- High-stakes claims require primary-source review and human approval.",
        "- The tool does not verify current facts unless current sources are supplied.",
    ]
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def write_all_outputs(out_dir: str | Path, report: ProofLedgerReport, sources: List[Source]) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "proofledger_report.json", report.to_dict())
    write_json(out / "claim_cards.json", [c.to_dict() for c in report.claim_cards])
    write_claim_cards_csv(out / "claim_cards.csv", report)
    write_alignment_csv(out / "evidence_alignment_matrix.csv", report)
    write_source_coverage(out / "source_coverage.json", report, sources)
    write_recommendations(out / "recommendations.md", report)
