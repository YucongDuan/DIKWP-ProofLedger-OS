from __future__ import annotations

import re
from typing import Iterable, List, Set

CITATION_RE = re.compile(r"\[([A-Za-z0-9_\-:]+)\]")
SENTENCE_SPLIT_RE = re.compile(r"(?<=[。！？.!?])\s+|\n+")
TOKEN_RE = re.compile(r"[A-Za-z0-9_\-]+|[\u4e00-\u9fff]")
STOPWORDS: Set[str] = {
    "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with", "by", "is", "are", "was", "were", "be", "as", "it", "this", "that",
    "是", "的", "了", "和", "与", "在", "对", "为", "中", "及", "或", "也", "而", "并", "一个", "一种"
}

STRONG_CLAIM_TERMS = [
    "guarantee", "guaranteed", "always", "never", "only", "best", "certain", "必然", "唯一", "绝对", "保证", "一定", "最", "永远", "从不"
]
ACTION_TERMS = ["should", "must", "recommend", "建议", "应该", "必须", "采取", "部署", "购买", "投资"]
NUMERIC_RE = re.compile(r"\d+(\.\d+)?\s*(%|percent|美元|元|twh|kwh|j|kg|gco2|年|月|日)?", re.I)


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip())


def split_sentences(text: str) -> List[str]:
    raw = [normalize_text(x) for x in SENTENCE_SPLIT_RE.split(text) if normalize_text(x)]
    # Split long bullet paragraphs by semicolon-ish punctuation while retaining compact claims.
    out: List[str] = []
    for item in raw:
        if len(item) > 240:
            parts = re.split(r"(?<=[；;])\s*", item)
            out.extend([p.strip() for p in parts if p.strip()])
        else:
            out.append(item)
    return out


def extract_citations(text: str) -> List[str]:
    return CITATION_RE.findall(text)


def tokenize(text: str) -> List[str]:
    toks = [t.lower() for t in TOKEN_RE.findall(text)]
    return [t for t in toks if t not in STOPWORDS and len(t.strip()) > 0]


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def has_numeric(text: str) -> bool:
    return NUMERIC_RE.search(text) is not None


def classify_claim(text: str) -> str:
    lowered = text.lower()
    if any(t in lowered for t in ACTION_TERMS) or any(t in text for t in ["建议", "应该", "必须", "采取"]):
        return "action_or_recommendation"
    if has_numeric(text):
        return "quantitative"
    if any(t in lowered for t in ["because", "therefore", "原因", "因此", "所以"]):
        return "causal_or_explanatory"
    return "factual"


def strength_flags(text: str) -> List[str]:
    lowered = text.lower()
    flags: List[str] = []
    for term in STRONG_CLAIM_TERMS:
        if term in lowered or term in text:
            flags.append("strong_unqualified_language")
            break
    if has_numeric(text):
        flags.append("numeric_claim")
    if len(text) > 220:
        flags.append("compound_claim")
    return flags


def compact_snippet(text: str, terms: List[str], limit: int = 220) -> str:
    clean = normalize_text(text)
    if len(clean) <= limit:
        return clean
    lower = clean.lower()
    positions = [lower.find(t.lower()) for t in terms if lower.find(t.lower()) >= 0]
    start = max(min(positions) - 60, 0) if positions else 0
    return ("..." if start else "") + clean[start:start + limit] + ("..." if start + limit < len(clean) else "")
