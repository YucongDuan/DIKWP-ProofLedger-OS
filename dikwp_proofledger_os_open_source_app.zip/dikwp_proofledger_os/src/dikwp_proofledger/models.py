from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any


@dataclass
class Source:
    source_id: str
    title: str
    text: str
    url: Optional[str] = None
    date: Optional[str] = None
    source_type: str = "document"
    reliability_hint: str = "Borrowed"


@dataclass
class Claim:
    claim_id: str
    text: str
    citations: List[str] = field(default_factory=list)
    claim_type: str = "factual"
    strength_flags: List[str] = field(default_factory=list)


@dataclass
class EvidenceMatch:
    source_id: str
    score: float
    matched_terms: List[str]
    snippet: str


@dataclass
class ClaimCard:
    claim_id: str
    claim_text: str
    citations: List[str]
    claim_type: str
    support_score: float
    citation_validity_score: float
    evidence_matches: List[EvidenceMatch]
    risk_flags: List[str]
    dikwp: Dict[str, Any]
    reliability: str
    decision: str
    kill_conditions: List[str]
    recovery_actions: List[str]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        return data


@dataclass
class ProofLedgerReport:
    system: str
    version: str
    purpose: str
    answer_length_chars: int
    source_count: int
    claim_count: int
    supported_count: int
    review_count: int
    blocked_count: int
    mean_support_score: float
    mean_citation_validity_score: float
    evidence_coverage_score: float
    unsupported_claim_rate: float
    citation_abuse_rate: float
    proofledger_score: float
    decision_summary: Dict[str, int]
    action_boundary: List[str]
    residual: List[str]
    claim_cards: List[ClaimCard]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
