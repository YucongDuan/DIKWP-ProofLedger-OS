from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "subprocess", "requests", "httpx", "urllib", "ftplib", "paramiko", "telnetlib"}
FORBIDDEN_CALLS = {"system", "popen", "exec", "eval", "remove", "unlink", "rmdir"}


def audit_path(root: str | Path) -> Dict:
    root_path = Path(root)
    findings: List[Dict] = []
    files_checked = 0
    for path in root_path.rglob("*.py"):
        files_checked += 1
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            findings.append({"file": str(path), "type": "syntax_error", "detail": str(exc)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root_name = alias.name.split(".")[0]
                    if root_name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root_name = node.module.split(".")[0]
                    if root_name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                name = None
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr
                if name in FORBIDDEN_CALLS:
                    findings.append({"file": str(path), "type": "forbidden_call", "detail": name})
    return {
        "system": "DIKWP ProofLedger OS static boundary audit",
        "files_checked": files_checked,
        "finding_count": len(findings),
        "pass": len(findings) == 0,
        "findings": findings,
        "boundary": "No network, subprocess, destructive filesystem calls, or dynamic code execution should be present in this local verifier."
    }


def write_audit(root: str | Path, out_path: str | Path) -> Dict:
    report = audit_path(root)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
