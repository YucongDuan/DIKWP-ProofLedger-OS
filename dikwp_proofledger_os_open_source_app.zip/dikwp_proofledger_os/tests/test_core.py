from dikwp_proofledger.analyzer import ProofLedgerAnalyzer
from dikwp_proofledger.models import Source


def test_supported_and_blocked_claims():
    answer = "The tool creates claim cards [S1]. The tool guarantees all truth."
    sources = [Source(source_id="S1", title="Brief", text="The tool creates claim cards and evidence ledgers. It does not guarantee truth.")]
    report = ProofLedgerAnalyzer().verify(answer, sources)
    assert report.claim_count == 2
    assert report.decision_summary["allow"] >= 1 or report.decision_summary["review"] >= 1
    assert report.decision_summary["block"] >= 1


def test_missing_citation_review_or_block():
    answer = "The system should be used for high-stakes legal advice without review."
    sources = [Source(source_id="S1", title="Boundary", text="High-stakes legal claims require human review.")]
    report = ProofLedgerAnalyzer().verify(answer, sources)
    assert report.claim_count == 1
    assert report.claim_cards[0].decision in {"review", "block"}


def test_citation_id_not_found_blocks():
    answer = "This claim is supported [MISSING]."
    sources = [Source(source_id="S1", title="Source", text="This claim is supported by source S1.")]
    report = ProofLedgerAnalyzer().verify(answer, sources)
    assert report.claim_cards[0].reliability == "Blocked"
