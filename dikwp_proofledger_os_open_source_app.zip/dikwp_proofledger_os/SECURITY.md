# Security Policy

Report vulnerabilities by opening a private issue or contacting the maintainer. This project is designed as a local verifier and should not collect secrets.
